idf_component_register(SRCS "storage.c" INCLUDE_DIRS "." REQUIRES cyd_common board fatfs)
