"""Real packaged Lua apps, native bindings and LVGL at both panels/all rotations."""
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
class Essentials(unittest.TestCase):
 def test_packages_and_real_app_workflows(self):
  if not os.getenv('IDF_PATH'):self.skipTest('ESP-IDF required for native cJSON')
  spec=importlib.util.spec_from_file_location('suite',ROOT/'scripts/build_essentials.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
  build=ROOT/'build-platform-host'
  subprocess.run(['cmake','-S',str(ROOT/'tests/platform_host'),'-B',str(build)],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['cmake','--build',str(build),'--parallel','4'],check=True,stdout=subprocess.DEVNULL)
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);results=suite.build(p/'packages',p/'staging');self.assertEqual(len(results),6)
   preview=Path(os.getenv('CYD_ESSENTIALS_PREVIEW_DIR',str(p/'previews')));preview.mkdir(parents=True,exist_ok=True)
   for w,h in [(240,320),(320,240),(800,480),(480,800)]:
    for name in ['api',*suite.APPS]:
     with self.subTest(app=name,size=(w,h)):
      r=subprocess.run([str(build/'essentials_host'),str(p/'staging'/('notes' if name=='api' else name)),str(w),str(h),name,str(preview)],capture_output=True,text=True)
      self.assertEqual(r.returncode,0,r.stdout+r.stderr)
