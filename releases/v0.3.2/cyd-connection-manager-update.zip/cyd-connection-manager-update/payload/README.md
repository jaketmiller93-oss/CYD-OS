# CYD OS — wireless Lua application development

An ESP-IDF MVP for **Elecrow CrowPanel Advance 4.3-inch DIS01943A V1.1–V1.3**
and **RockBase NM-CYD-C5 V1.0 with ST7789**.
Edit an application on Linux, upload a `.cydapp` over Wi-Fi, and start a new Lua
context without flashing or rebooting the ESP32.

**The build environment has no physical hardware access.** The manufacturer’s V1.3 schematic
and V1.1–V1.3 examples were checked. Your physical revision is still unconfirmed;
board initialization is disabled by default until you confirm it in menuconfig.
CrowPanel V1.0 and C5 panels other than ST7789 are not supported by these profiles.
The user has confirmed C5 boot, corrected touch mapping, Wi-Fi, SD uploads and
wireless Lua app updates. The new connection manager still needs on-device validation.

## Included

- Native ESP-IDF 5.5.4 project; S3 RGB565 800×480 / GT911 and C5 SPI
  ST7789 320×240 / XPT2046 HALs, with separate target memory settings.
- LVGL 9.1 dark shell: Connections, Projects (tap a revision to launch), Diagnostics,
  Logs, status bar, and persistent Home / Stop control outside the app container.
- Touchscreen [connection manager](docs/CONNECTIONS.md): scan/join Wi-Fi, five
  saved profiles, on-screen keyboard, reconnect/forget, and protected AP control.
- FAT SD storage, station/AP/AP+station operation, separate IP display, mDNS.
- Authenticated browser dashboard and deployment API: upload, list, run, stop,
  delete and download revisions; polling logs and memory/storage diagnostics.
- Lua 5.4.8: labels, buttons, click callbacks, private persistent storage, logging,
  bounded memory, instruction hooks, and one foreground application.
- `cydctl`: reproducible stored-ZIP packages, deployment, confirmed startup,
  revision selection, logs, download, and machine-readable output.
- Staging/commit installation: incomplete staging is removed at boot; previous
  revisions and application data are retained. Apps do not auto-run at boot.

This is an incremental MVP. The acceptance milestone still requires the
[physical test procedure](docs/TESTING.md). It is not a hardware-validated release.

## Build and first flash on Linux

Install ESP-IDF’s documented Linux prerequisites (including CMake, Ninja, Git,
GCC, Python and a virtual environment), then:

```bash
git clone --branch v5.5.4 --depth 1 --recursive https://github.com/espressif/esp-idf.git ~/esp/esp-idf
~/esp/esp-idf/install.sh esp32s3
. ~/esp/esp-idf/export.sh
cd /path/to/cyd-os
python scripts/fetch_lua.py
idf.py set-target esp32s3
idf.py menuconfig
```

For the C5, use the **separate build commands in [HARDWARE-C5.md](docs/HARDWARE-C5.md)**.
The commands above default to the CrowPanel.

Read [HARDWARE.md](docs/HARDWARE.md) before enabling **CYD OS → verified board**.
Confirm the physical product and revision. For V1.1–V1.3, power down and set the
manufacturer’s function selector to **S1=1, S0=1 (MIC & TF Card)**. Insert a FAT32
microSD card. Do not format automatically; the firmware never does so.

Under **CYD OS**, optionally set initial station SSID/password and an initial AP
password (12–63 characters). These are imported once into NVS. Afterward, use
**Connections** on the touchscreen; see [CONNECTIONS.md](docs/CONNECTIONS.md).
With no station credentials, a protected AP starts; a blank initial AP password
generates one that can be viewed in physical AP settings. Set an independent deployment bearer token (24–240
characters; for example generate one with `python -c 'import secrets;
print(secrets.token_hex(24))'`). A blank deployment token disables the web API. Configurations and build outputs contain secrets; keep them private.

```bash
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

Choose your actual serial device. This first USB flash installs the bootloader,
partition table and OS. USB power can stay connected afterward. Future **Lua app**
deployments need no USB data connection or reset.

The shell shows the IP; open `http://<device-ip>/` and enter the token. In AP mode,
join the displayed AP name (initially `CYD-OS`) with its configured/generated password, then open `http://192.168.4.1/`.
`http://cyd.local/` depends on the client/network supporting mDNS.

## Wireless development loop

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e tools/cydctl
read -rs -p 'CYD token: ' CYD_TOKEN; export CYD_TOKEN; echo
export CYD_DEVICE=192.168.4.1   # or the station IP / cyd.local
cydctl status --json
cydctl deploy apps/hello --device "$CYD_DEVICE" --run --logs --json
cydctl logs --follow
```

Modify `apps/hello/main.lua`, bump `manifest.json`’s version if desired, and repeat
`deploy`. Each upload receives a new immutable revision ID even when its semantic
version is unchanged. `--run` stops the previous app, creates a new Lua state, and
waits for `running`; startup errors return a nonzero exit status. Old revisions
remain selectable in Projects and the browser.

```bash
cydctl versions --json
cydctl run 0123456789abcdef             # use a real saved revision
cydctl stop
cydctl download 0123456789abcdef -o hello.cydapp
cydctl delete 0123456789abcdef          # explicit permanent revision deletion
cydctl pack apps/hello -o /tmp/hello.cydapp
```

Use `--token-file /private/path/token` instead of the environment if preferred.
`devices` resolves the configured hostname; it is not a network scanner. `projects`
is an alias for the flat revision listing in this MVP. Select an older revision
with `run` to roll back executable code; app data is shared across revisions of
the same package and is not rolled back. `download` exports one package, not data.

## Architecture

`components/board` selects either `boards/crowpanel_s3` or `boards/nm_cyd_c5`;
each HAL owns its display/touch/SD pins. Common services do not assume a chip or resolution. `storage` owns the mounted
filesystem. `app_manager` validates and stages packages. `app_runtime` owns the
Lua state, bounded allocator, lifecycle and event queue. `ui` owns the LVGL task
and a recursive lock; all app widget operations use that lock. `network` configures
Wi-Fi and mDNS. `web_api` authenticates every API request before accessing software
or logs. The common component defines the interface and strict ZIP reader.

A separate Lua task executes the entry point and callbacks. UI events enqueue Lua
registry references; they never execute Lua on the UI task. The permanent shell
navigation requests cooperative cancellation. Shutdown blocks further API calls, closes Lua while handles are still valid, then
destroys app widgets/handlers before allowing the next launch. Each launch reopens private data under `/sdcard/cydos/data/<package_id>`.

See [API.md](docs/API.md), [HARDWARE.md](docs/HARDWARE.md),
[HARDWARE-C5.md](docs/HARDWARE-C5.md), [TESTING.md](docs/TESTING.md),
[RECOVERY.md](docs/RECOVERY.md), and the
[original specification](docs/SPECIFICATION.md).

## Current limitations and next phases

- The new connection manager and CrowPanel still need physical acceptance tests.
  The RGB path uses a PSRAM framebuffer and
  internal bounce/draw buffers; tearing is possible and must be measured under
  SD/Wi-Fi load. Touch orientation and fixed-low SD select need physical checks.
- Lua is a controlled API, not a security boundary. Hooks limit Lua instructions;
  C library calls and blocked SD I/O are not forcibly preempted. A stop timeout
  prevents a second app from starting; recovery may require reset. No untrusted
  code or untrusted-network deployment is intended.
- Only stored ZIP archives are accepted; use `cydctl pack` or the Python ZIP_STORED
  format. Limits: 512 KiB/package, 48 files, 64 KiB/file, 4 KiB manifest,
  lowercase ASCII relative paths. No ZIP64, encryption, links or compressed ZIPs.
- Storage permission is supported. UART/I²C/GPIO/network APIs, resource leases,
  images, lists, sliders, inputs and charts remain future phases; unsupported
  manifest permissions are rejected instead of silently granted.
- No arbitrary file browser, folders, pinned
  home apps, saved layout, automatic last-known-working selection, retention
  policy, named project metadata, full backups or app-data quotas yet. An app’s
  storage files are each capped at 16 KiB; repeated writes can still fill the SD.
- Wi-Fi/AP profiles are editable on the touchscreen and stored in NVS. The
  deployment token remains build-time configuration. HTTP uses bearer auth
  over a trusted protected local network; it supplies no transport encryption.
  No API redirects or CORS access are enabled. Core code never logs credentials;
  applications are responsible for not printing sensitive application data.
- Logs are a volatile 64-entry ring. Dashboard polling refreshes the whole ring;
  no WebSocket stream, debugger, SNTP/RTC time, battery, audio or BLE support yet.
- A/B flash space is reserved, but OS OTA, boot validation/rollback, and standalone
  firmware launching are **not implemented**. Do not upload `.bin` as an app or
  use this partition table for unrelated firmware.
- SD updates use flushed files and a directory rename; FAT is not a transactional
  filesystem. Power loss can corrupt a card. Keep desktop source and backups.

The roadmap follows the specification: validate Phase 1 hardware, validate the
implemented Phase 2–4 path on-device, complete project management, then add hardware
APIs, authenticated OS OTA/recovery, and further board variants. Both initial HALs
are implemented; see the validation records for completed software checks and
remaining physical tests.
