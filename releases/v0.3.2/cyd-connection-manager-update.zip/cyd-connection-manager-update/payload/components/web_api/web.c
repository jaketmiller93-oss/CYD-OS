#include "cyd.h"
#include "cyd_network.h"
#include "sdkconfig.h"
#include "esp_http_server.h"
#include "esp_heap_caps.h"
#include "esp_psram.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
extern const char dashboard_start[] asm("_binary_dashboard_html_start");
static esp_err_t json(httpd_req_t *r, cJSON *o) {
    if (!o)
        return httpd_resp_send_err(r, HTTPD_500_INTERNAL_SERVER_ERROR, "Allocation failed");
    char *s = cJSON_PrintUnformatted(o);
    cJSON_Delete(o);
    if (!s)
        return ESP_ERR_NO_MEM;
    httpd_resp_set_type(r, "application/json");
    httpd_resp_set_hdr(r, "Cache-Control", "no-store");
    esp_err_t e = httpd_resp_sendstr(r, s);
    free(s);
    return e;
}
static bool auth(httpd_req_t *r) {
    char got[256], want[256];
    snprintf(want, sizeof(want), "Bearer %s", CONFIG_CYD_API_TOKEN);
    size_t n = strlen(want), len = httpd_req_get_hdr_value_len(r, "Authorization");
    unsigned diff = (unsigned)(n ^ len);
    if (len >= sizeof(got) ||
        httpd_req_get_hdr_value_str(r, "Authorization", got, sizeof(got)) != ESP_OK)
        diff = 1;
    else {
        for (size_t i = 0; i < n; i++)
            diff |= (unsigned char)want[i] ^ (unsigned char)(i < len ? got[i] : 0);
    }
    if (!diff)
        return true;
    httpd_resp_set_status(r, "401 Unauthorized");
    httpd_resp_set_hdr(r, "WWW-Authenticate", "Bearer");
    httpd_resp_sendstr(r, "{\"error\":\"Authentication required\"}");
    return false;
}
static esp_err_t failure(httpd_req_t *r, esp_err_t e, const char *msg) {
    httpd_resp_set_status(r, e == ESP_ERR_NOT_FOUND       ? "404 Not Found"
                             : e == ESP_ERR_TIMEOUT       ? "503 Service Unavailable"
                             : e == ESP_ERR_INVALID_STATE ? "409 Conflict"
                                                          : "400 Bad Request");
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "error", msg);
    return json(r, o);
}
static bool revision(httpd_req_t *r, char *out) {
    char q[128];
    if (httpd_req_get_url_query_str(r, q, sizeof(q)) ||
        httpd_query_key_value(q, "revision", out, 17))
        return false;
    if (strlen(out) != 16)
        return false;
    for (int i = 0; i < 16; i++)
        if (!((out[i] >= '0' && out[i] <= '9') || (out[i] >= 'a' && out[i] <= 'f')))
            return false;
    return true;
}
static esp_err_t index_page(httpd_req_t *r) {
    httpd_resp_set_type(r, "text/html");
    httpd_resp_set_hdr(r, "X-Content-Type-Options", "nosniff");
    httpd_resp_set_hdr(
        r, "Content-Security-Policy",
        "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src "
        "'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    return httpd_resp_sendstr(r, dashboard_start);
}
static esp_err_t status(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    char ip[32];
    cyd_network_address(ip, sizeof(ip));
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "model", cyd_board_model());
    cJSON_AddStringToObject(o, "firmware", CYD_VERSION);
    cJSON_AddStringToObject(o, "target", CONFIG_IDF_TARGET);
    cJSON_AddStringToObject(o, "ip", ip);
    cJSON_AddBoolToObject(o, "wifi", cyd_network_connected());
    cJSON_AddBoolToObject(o, "sd", cyd_storage_ready());
    cJSON_AddNumberToObject(o, "heap_free", esp_get_free_heap_size());
    cJSON_AddNumberToObject(o, "largest_block", heap_caps_get_largest_free_block(MALLOC_CAP_8BIT));
    cJSON_AddNumberToObject(o, "psram_total", esp_psram_get_size());
    cJSON_AddNumberToObject(o, "psram_free", heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    cJSON_AddNumberToObject(o, "internal_heap_free", heap_caps_get_free_size(MALLOC_CAP_INTERNAL));
    cJSON_AddNumberToObject(o, "storage_free", cyd_storage_free());
    cJSON_AddItemToObject(o, "app", cyd_runtime_status());
    cyd_net_status_t ns;
    cyd_network_snapshot(&ns);
    cJSON *net = cJSON_CreateObject();
    cJSON_AddBoolToObject(net, "ready", ns.ready);
    cJSON_AddBoolToObject(net, "scanning", ns.scanning);
    cJSON_AddStringToObject(net, "state",
                            ns.state == CYD_NET_CONNECTED    ? "connected"
                            : ns.state == CYD_NET_CONNECTING ? "connecting"
                            : ns.state == CYD_NET_FAILED     ? "failed"
                                                             : "offline");
    cJSON_AddStringToObject(net, "station_ssid", ns.ssid);
    cJSON_AddStringToObject(net, "station_ip", ns.station_ip);
    cJSON_AddBoolToObject(net, "ap_enabled", ns.ap_enabled);
    cJSON_AddStringToObject(net, "ap_ssid", ns.ap_ssid);
    cJSON_AddStringToObject(net, "ap_ip", ns.ap_ip);
    cJSON_AddStringToObject(net, "message", ns.message);
    cJSON_AddNumberToObject(net, "saved_count", ns.saved_count);
    cJSON_AddItemToObject(o, "network", net);
    return json(r, o);
}
static esp_err_t versions(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    return json(r, cyd_versions());
}
static esp_err_t logs_handler(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    return json(r, cyd_logs());
}
static esp_err_t upload(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    if (!cyd_storage_ready())
        return failure(r, ESP_ERR_INVALID_STATE, "SD card unavailable");
    if (r->content_len < 22 || r->content_len > CYD_MAX_PACKAGE)
        return failure(r, ESP_ERR_INVALID_SIZE, "Package limit 512 KiB");
    uint8_t *b = malloc(r->content_len);
    if (!b)
        return failure(r, ESP_ERR_NO_MEM, "Allocation failed");
    size_t offset = 0;
    while (offset < r->content_len) {
        int n = httpd_req_recv(r, (char *)b + offset, r->content_len - offset);
        if (n <= 0) {
            free(b);
            return failure(r, ESP_ERR_TIMEOUT, "Upload interrupted");
        }
        offset += n;
    }
    char rev[17], error[128];
    esp_err_t e = cyd_install(b, offset, rev, sizeof(rev), error, sizeof(error));
    free(b);
    if (e)
        return failure(r, e, error);
    httpd_resp_set_status(r, "201 Created");
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "revision", rev);
    cJSON_AddStringToObject(o, "status", "installed");
    return json(r, o);
}
static esp_err_t run(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    char rev[17];
    if (!revision(r, rev))
        return failure(r, ESP_ERR_INVALID_ARG, "Expected revision");
    esp_err_t e = cyd_run_revision(rev);
    if (e)
        return failure(r, e, esp_err_to_name(e));
    httpd_resp_set_status(r, "202 Accepted");
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "status", "starting");
    return json(r, o);
}
static esp_err_t stop(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    esp_err_t e = cyd_runtime_stop();
    if (e)
        return failure(r, e, "App has not stopped");
    return json(r, cyd_runtime_status());
}
static esp_err_t remove_version(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    char rev[17];
    if (!revision(r, rev))
        return failure(r, ESP_ERR_INVALID_ARG, "Expected revision");
    esp_err_t e = cyd_delete_revision(rev);
    if (e)
        return failure(r, e, esp_err_to_name(e));
    cJSON *o = cJSON_CreateObject();
    cJSON_AddBoolToObject(o, "deleted", true);
    return json(r, o);
}
static esp_err_t download(httpd_req_t *r) {
    if (!auth(r))
        return ESP_OK;
    char rev[17];
    if (!revision(r, rev))
        return failure(r, ESP_ERR_INVALID_ARG, "Expected revision");
    char path[180];
    snprintf(path, sizeof(path), CYD_ROOT "/projects/%s/package.cydapp", rev);
    FILE *f = fopen(path, "rb");
    if (!f)
        return failure(r, ESP_ERR_NOT_FOUND, "Revision not found");
    httpd_resp_set_type(r, "application/zip");
    httpd_resp_set_hdr(r, "Content-Disposition", "attachment; filename=application.cydapp");
    char b[2048];
    size_t n;
    esp_err_t e = ESP_OK;
    while ((n = fread(b, 1, sizeof(b), f)) && e == ESP_OK)
        e = httpd_resp_send_chunk(r, b, n);
    bool failed = ferror(f);
    fclose(f);
    if (e || failed)
        return ESP_FAIL;
    return httpd_resp_send_chunk(r, NULL, 0);
}
esp_err_t cyd_web_start(void) {
    size_t n = strlen(CONFIG_CYD_API_TOKEN);
    if (n < 24 || n > 240)
        return ESP_ERR_INVALID_ARG;
    httpd_config_t c = HTTPD_DEFAULT_CONFIG();
    c.stack_size = 12288;
    c.max_uri_handlers = 12;
    c.recv_wait_timeout = 10;
    c.send_wait_timeout = 10;
    c.lru_purge_enable = true;
    httpd_handle_t server;
    esp_err_t e = httpd_start(&server, &c);
    if (e)
        return e;
    const httpd_uri_t routes[] = {
        {.uri = "/", .method = HTTP_GET, .handler = index_page},
        {.uri = "/api/status", .method = HTTP_GET, .handler = status},
        {.uri = "/api/versions", .method = HTTP_GET, .handler = versions},
        {.uri = "/api/logs", .method = HTTP_GET, .handler = logs_handler},
        {.uri = "/api/packages", .method = HTTP_POST, .handler = upload},
        {.uri = "/api/run", .method = HTTP_POST, .handler = run},
        {.uri = "/api/stop", .method = HTTP_POST, .handler = stop},
        {.uri = "/api/versions", .method = HTTP_DELETE, .handler = remove_version},
        {.uri = "/api/download", .method = HTTP_GET, .handler = download}};
    for (unsigned i = 0; i < sizeof(routes) / sizeof(*routes); i++) {
        e = httpd_register_uri_handler(server, &routes[i]);
        if (e) {
            httpd_stop(server);
            return e;
        }
    }
    return ESP_OK;
}
