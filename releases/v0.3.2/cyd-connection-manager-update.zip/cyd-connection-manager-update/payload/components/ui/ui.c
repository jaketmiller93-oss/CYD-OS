#include "cyd.h"
#include "connections.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "esp_psram.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/queue.h"
static SemaphoreHandle_t lock;
static lv_obj_t *home, *app, *status, *details, *content;
static QueueHandle_t actions;
static unsigned width, height;
typedef struct {
    int kind;
    char revision[17];
} action_t;
void cyd_ui_lock(void) {
    xSemaphoreTakeRecursive(lock, portMAX_DELAY);
}
void cyd_ui_unlock(void) {
    xSemaphoreGiveRecursive(lock);
}
lv_obj_t *cyd_ui_app_root(void) {
    return app;
}
void cyd_ui_show_app(bool show) {
    if (show) {
        lv_obj_add_flag(home, LV_OBJ_FLAG_HIDDEN);
        lv_obj_remove_flag(app, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(app, LV_OBJ_FLAG_HIDDEN);
        lv_obj_remove_flag(home, LV_OBJ_FLAG_HIDDEN);
    }
}
static uint32_t tick(void) {
    return esp_timer_get_time() / 1000;
}
static void go_home(lv_event_t *e) {
    (void)e;
    cyd_runtime_request_stop();
    cyd_connections_close();
    lv_obj_scroll_to_y(home, 0, LV_ANIM_OFF);
}
static void menu(lv_event_t *e) {
    action_t a = {.kind = (int)(intptr_t)lv_event_get_user_data(e)};
    xQueueSend(actions, &a, 0);
}
static void launch(lv_event_t *e) {
    action_t a = {.kind = 4};
    snprintf(a.revision, sizeof(a.revision), "%s", (char *)lv_event_get_user_data(e));
    xQueueSend(actions, &a, 0);
}
static void free_revision(lv_event_t *e) {
    free(lv_event_get_user_data(e));
}
static void action_task(void *arg) {
    (void)arg;
    action_t a;
    while (xQueueReceive(actions, &a, portMAX_DELAY)) {
        if (a.kind == 4) {
            esp_err_t e = cyd_run_revision(a.revision);
            if (e)
                cyd_log("launcher", esp_err_to_name(e));
            continue;
        }
        if (a.kind == 0) {
            cyd_ui_lock();
            cyd_connections_open();
            cyd_ui_unlock();
            continue;
        }
        cJSON *data = a.kind == 1 ? cyd_versions() : a.kind == 3 ? cyd_logs() : NULL;
        cyd_ui_lock();
        lv_obj_clean(content);
        details = lv_label_create(content);
        lv_obj_set_width(details, width - 80);
        if (a.kind == 1) {
            lv_label_set_text(details, "Saved revisions (tap to launch)");
            int y = 30;
            unsigned count = 0;
            cJSON *v;
            cJSON_ArrayForEach(v, data) {
                if (count++ >= 32)
                    break;
                const char *r = cJSON_GetObjectItem(v, "revision")->valuestring;
                char text[160];
                snprintf(text, sizeof(text), "%s  %s  %.8s",
                         cJSON_GetObjectItem(v, "name")->valuestring,
                         cJSON_GetObjectItem(v, "version")->valuestring, r);
                char *copy = strdup(r);
                if (!copy)
                    break;
                lv_obj_t *b = lv_button_create(content);
                lv_obj_set_pos(b, 0, y);
                lv_obj_set_size(b, width - 88, 48);
                y += 56;
                lv_obj_t *l = lv_label_create(b);
                lv_label_set_text(l, text);
                lv_obj_center(l);
                lv_obj_add_event_cb(b, launch, LV_EVENT_CLICKED, copy);
                lv_obj_add_event_cb(b, free_revision, LV_EVENT_DELETE, copy);
            }
            if (!count)
                lv_label_set_text(
                    details,
                    "No installed revisions. Upload a .cydapp from the dashboard or cydctl.");
        }
        if (a.kind == 2) {
            char b[256];
            snprintf(b, sizeof(b),
                     "CYD OS %s\nHeap: %u bytes; largest block: %u bytes\nPSRAM detected: %u "
                     "bytes\nSD card: %s\nPress Home to stop any running Lua app.",
                     CYD_VERSION, (unsigned)esp_get_free_heap_size(),
                     (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
                     (unsigned)esp_psram_get_size(), cyd_storage_ready() ? "ready" : "unavailable");
            lv_label_set_text(details, b);
        }
        if (a.kind == 3) {
            char b[4096] = "";
            size_t used = 0;
            cJSON *v;
            cJSON_ArrayForEach(v, data) {
                size_t n = strlen(v->valuestring);
                if (n + used + 2 >= sizeof(b))
                    break;
                memcpy(b + used, v->valuestring, n);
                used += n;
                b[used++] = '\n';
                b[used] = 0;
            }
            lv_label_set_text(details, used ? b : "No logs yet.");
        }
        lv_obj_scroll_to_view_recursive(details, LV_ANIM_OFF);
        cyd_ui_unlock();
        cJSON_Delete(data);
    }
}
static void refresh(lv_timer_t *t) {
    (void)t;
    char ip[32], text[180];
    cyd_network_address(ip, sizeof(ip));
    snprintf(text, sizeof(text), "CYD OS     %s     SD: %s     Free: %llu KiB", ip,
             cyd_storage_ready() ? "ready" : "unavailable",
             (unsigned long long)cyd_storage_free() / 1024);
    lv_label_set_text(status, text);
}
static void task(void *arg) {
    (void)arg;
    while (true) {
        cyd_ui_lock();
        uint32_t ms = lv_timer_handler();
        cyd_ui_unlock();
        if (ms < 5)
            ms = 5;
        if (ms > 20)
            ms = 20;
        vTaskDelay(pdMS_TO_TICKS(ms));
    }
}
esp_err_t cyd_ui_init(void) {
    lock = xSemaphoreCreateRecursiveMutex();
    if (!lock)
        return ESP_ERR_NO_MEM;
    width = cyd_board_width();
    height = cyd_board_height();
    lv_init();
    lv_tick_set_cb(tick);
    lv_display_t *d = lv_display_create(width, height);
    if (!d)
        return ESP_ERR_NO_MEM;
    void *buf = heap_caps_malloc(width * 24 * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_DMA);
    if (!buf)
        return ESP_ERR_NO_MEM;
    lv_display_set_color_format(d, LV_COLOR_FORMAT_RGB565);
    lv_display_set_buffers(d, buf, NULL, width * 24 * 2, LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_flush_cb(d, cyd_board_flush);
    lv_indev_t *i = lv_indev_create();
    if (!i)
        return ESP_ERR_NO_MEM;
    lv_indev_set_type(i, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(i, cyd_board_touch);
    lv_theme_t *theme =
        lv_theme_default_init(d, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_CYAN),
                              true, LV_FONT_DEFAULT);
    lv_display_set_theme(d, theme);
    lv_obj_t *screen = lv_screen_active();
    lv_obj_set_style_bg_color(screen, lv_color_hex(0x101522), 0);
    status = lv_label_create(screen);
    lv_obj_set_pos(status, 8, 5);
    lv_obj_set_width(status, width - 16);
    lv_label_set_long_mode(status, LV_LABEL_LONG_DOT);
    home = lv_obj_create(screen);
    lv_obj_set_pos(home, 0, 28);
    lv_obj_set_size(home, width, height - 84);
    lv_obj_set_style_pad_all(home, 8, 0);
    lv_obj_t *title = lv_label_create(home);
    lv_label_set_text(title, "Wireless app workspace");
    lv_obj_set_pos(title, 4, 0);
    const char *names[] = {"Connections", "Projects", "Diagnostics", "Logs"};
    actions = xQueueCreate(8, sizeof(action_t));
    if (!actions)
        return ESP_ERR_NO_MEM;
    for (int n = 0; n < 4; n++) {
        lv_obj_t *b = lv_button_create(home);
        lv_obj_set_pos(b, 4 + (n % (width < 480 ? 2 : 4)) * ((width - 28) / (width < 480 ? 2 : 4)),
                       30 + (n / (width < 480 ? 2 : 4)) * 54);
        lv_obj_set_size(b, (width - 40) / (width < 480 ? 2 : 4), 46);
        lv_obj_t *l = lv_label_create(b);
        lv_label_set_text(l, names[n]);
        lv_obj_center(l);
        lv_obj_add_event_cb(b, menu, LV_EVENT_CLICKED, (void *)(intptr_t)n);
    }
    content = lv_obj_create(home);
    int content_y = width < 480 ? 142 : 88;
    lv_obj_set_pos(content, 0, content_y);
    lv_obj_set_size(content, width - 20, width < 480 ? 200 : height - 210);
    details = lv_label_create(content);
    lv_obj_set_width(details, width - 80);
    lv_label_set_text(
        details,
        "Develop on Linux. Deploy over Wi-Fi.\nOpen the device IP in your browser to get started.");
    app = lv_obj_create(screen);
    lv_obj_set_pos(app, 0, 28);
    lv_obj_set_size(app, width, height - 84);
    lv_obj_add_flag(app, LV_OBJ_FLAG_HIDDEN);
    lv_obj_t *b = lv_button_create(screen);
    lv_obj_set_pos(b, (width - 200) / 2, height - 50);
    lv_obj_set_size(b, 200, 48);
    lv_obj_t *l = lv_label_create(b);
    lv_label_set_text(l, "Home / Stop app");
    lv_obj_center(l);
    lv_obj_add_event_cb(b, go_home, LV_EVENT_CLICKED, NULL);
    cyd_connections_init(screen, width, height);
    lv_timer_create(refresh, 2000, NULL);
    if (xTaskCreate(action_task, "shell_actions", 12288, NULL, 3, NULL) != pdPASS)
        return ESP_ERR_NO_MEM;
    return xTaskCreate(task, "ui", 8192, NULL, 5, NULL) == pdPASS ? ESP_OK : ESP_ERR_NO_MEM;
}
