idf_component_register(SRCS "ui.c" "connections.c" INCLUDE_DIRS "." REQUIRES cyd_common board app_runtime esp_timer esp_psram storage network)
