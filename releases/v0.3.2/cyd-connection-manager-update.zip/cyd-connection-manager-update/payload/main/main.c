#include "cyd.h"
#include "nvs_flash.h"
#include "esp_log.h"
void app_main(void) {
    esp_err_t e = nvs_flash_init();
    if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        e = nvs_flash_init();
    }
    ESP_ERROR_CHECK(e);
    ESP_ERROR_CHECK(cyd_runtime_init());
    ESP_ERROR_CHECK(cyd_manager_init());
    e = cyd_board_init();
    if (e) {
        ESP_LOGE("boot", "Board disabled or initialization failed: %s. See docs/HARDWARE.md",
                 esp_err_to_name(e));
        return;
    }
    e = cyd_storage_init();
    if (e)
        ESP_LOGE("boot", "SD unavailable: %s; shell remains usable", esp_err_to_name(e));
    e = cyd_network_init();
    ESP_ERROR_CHECK(cyd_ui_init());
    if (e) {
        ESP_LOGE("boot", "Connection service unavailable; check startup error");
        return;
    }
    e = cyd_web_start();
    if (e)
        ESP_LOGE("boot", "Deployment disabled: set a token of at least 24 characters");
}
